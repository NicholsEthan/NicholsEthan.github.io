﻿=== ViViD | Simplistic Cursor Set ===

By: Riptxde (http://www.rw-designer.com/user/62195) ru3l.go@gmail.com

Download: http://www.rw-designer.com/cursor-set/vivid-simplistic

Author's description:

A smooth tailless cursor set that uses a bright color range to express all 15 roles. Very simplistic and "vivid". It is colorful, multi-color, minimalistic and white and is very neat. Goes with most backgrounds and web pages! A modern set that is very animated yet not over-doing it. It is not too colorful but just a tint of a certain color over white, as well as a simplistic bevel.

Edit: Accidentally made Diagonal Resize 1 and 2 switched so make sure to switch those two around on installation.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.